## find the optimal value of theta
## by maximizing CV-loglik

simple_gp_fit=function(simple_x, jIter = 6,
                       trial_init = NULL){
    currL = 1e20
    theta0 = c(0,0)    
    optTheta = c(0,0)
    
    t0 = seq(-1,0.9,length.out=6)
    t1 = seq(15,150,length.out=5)
    for(j in 1:6){
        for(k in 1:5){
            theta0[1]= t0[j]
            theta0[2] = t1[k]
            simple_x$gp_setTheta(theta0)
            currL = simple_x$gp_mLoglik(theta0);
            try({
                opsR = optim(theta0, fn = simple_x$gp_mLoglik,
                             gr = simple_x$gp_DmLoglik, method="BFGS")
                if(opsR$value<currL){
                    currL=opsR$value
                    optTheta = opsR$par
                }
            })
        }
    }
    
    if(!is.null(trial_init)){
        for(j in 1:dim(trial_init)[2]){
            theta0[1] = trial_init[1,j]
            theta0[2] = trial_init[2,j]
            try({
                opsR = optim(theta0, 
                             fn = simple_x$gp_mLoglik,
                             gr = simple_x$gp_DmLoglik, 
                             method="BFGS")
                if(opsR$value<currL){
                    currL=opsR$value
                    optTheta = opsR$par
                }
            })
        }
    }
    
    return(list(currL = currL,optTheta = optTheta))
}


simple_gp_plot=function(starObs, newX, newY){
    plot(starObs[,1:2],pch=20,
         ylim=rev(range(starObs[,2])),
         ylab="Mag",xlab="MJD",type="n")
    bandX = c(newX,rev(newX))
    diagT = abs(diag(newY$predy_cov))
    newY_upper = newY$predy+1.643*sqrt(diagT) 
    newY_lower = newY$predy-1.643*sqrt(diagT) 
    bandY = c(newY_upper,rev(newY_lower))
    polygon(bandX,bandY,col="grey",border = NA)
    lines(newX,newY$predy,pch=20,col="red",lwd=3)
    sinPart= (newY$Ht_star)%*%(newY$gamma_bar)
    lines(newX,sinPart,col="blue",lwd = 2)
    points(starObs[,1:2],pch=20)
}


