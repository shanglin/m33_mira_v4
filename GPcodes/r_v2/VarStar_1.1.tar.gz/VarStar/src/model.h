#ifndef MODELBASECLASS
#define MODELBASECLASS

#define ARMA_DONT_PRINT_ERRORS
#include <RcppArmadillo.h>
#include <Rcpp.h>
//#include <cstdio>
//#include <cstdlib>
#include <cmath>
#include <vector>

using namespace Rcpp;
using namespace arma;


class varStar{
protected:
     //input
    //weight is the inverse of input error
    //       is also the inverse of mag_sigma
    vec MJD, mag, weight, mag_sigma;
    double period;
    
    //intermediate product
    int nCyc, nObs;
    //num of cycles, observations, Non-zero cycles 
    vec phase, cycPos; //phase: (0,1); cycPos: the num. of cycles in
    vec magFitted, residuals;
    //reserved value in bootstrap
    vec resid_res, mag_res, magFitted_res;
    
    //The design Matrix in regression
    //Also used in simple gaussian process model?
    mat DMbasis;

    //intermediate functions
    virtual void DMbasis_eval() {};
    void boot_shuffle();

 public:
    
    varStar(NumericVector, NumericVector, NumericVector);
    virtual void set_period(double, double );
    mat period_est(double , double , int );
    virtual double model_fit() {return 0;}
    virtual List get_model()  {return List::create(1);}
    virtual List get_fake(NumericVector, double ) {return List::create(1);} 
    virtual ~varStar() {}
};


#endif //MODELBASECLASS
