if(FALSE){
library(VarStar)
library(scales)

folder = "~/Dropbox/project/Astronomy/M33Var/CoreData/"
rdfiles = paste0(folder, "all_star_table.csv")

## The information table from OGLE
starTable = read.csv(rdfiles, header=TRUE)
starTable = subset(starTable, Type=="Mira")

## Get the k-th variable star
k=30 # 33 86 92 99 151 1128 1385
folder = "~/Dropbox/project/Astronomy/M33Var/CoreData/lightcurves/"
starID = starTable$ID[k]
rdfiles = paste0(folder, starID, ".dat")

## actual observations
starObs = read.table(rdfiles)

##True period
p0 = starTable$P_1[k]

## define new object of class "varStar"
## following three inputs should be MJD, mag, error
x = new(sinusoidModel,starObs$V1, starObs$V2 , starObs$V3)

## MUST set period before model fitting
x$set_period(p0,0)
x$model_fit()
starModel = x$get_model()
plotVS(starModel,FALSE)

## MUST set period before generating fake light curves
x$set_period(p0)
MJDf = c(2500, 2600, 2700, 2800,3500, 4700,5000,8000,8400,3000)
MJDf = 2500:15000
fakeL = x$get_fake(MJDf, 4.7)
deltaMJD = max(starModel$MJD)-min(starModel$MJD)
deltaMJD = ceiling(deltaMJD/p0) - 1
fTime = (MJDf-min(MJDf)+1528.54) %% (deltaMJD * p0) + min(starModel$MJD)
plotVS(starModel,FALSE)
lines(fTime,fakeL[,2],col=alpha("red",0.2),lwd=5)



# Period estimation
sBegin = 100 ## beginning of the search region
sEnd = 1500  ## end of the search region
sGrid = seq(sBegin, sEnd, length.out=1000)
residSeq = x$period_est(sBegin, sEnd, 1000)
## residuals plot
plot(sGrid, residSeq, type="l")
abline(v=p0,col="red")


y=new(varStar,fakeL[,1],fakeL[,2],fakeL[,3])
residSeq = y$period_est(sBegin, sEnd, 1000)
## residuals plot
plot(sGrid, residSeq, type="l")
abline(v=p0,col="red")

}
