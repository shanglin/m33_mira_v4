loadModule("varStar_m1", TRUE)
loadModule("varStar_m2", TRUE)
loadModule("varStar_m3", TRUE)

plotVS = function(vsModel, folding=FALSE){
    grid=seq(0,1,length.out=5000)
    mbasis = matrix(0,5000,2)
    pi = 3.141593
    mbasis[,1] = cos(grid*2*pi)
    mbasis[,2] = sin(grid*2*pi)
    
    nCyc = vsModel$nCyc
    cycPos = vsModel$cycPos
    ak = vsModel$ak
    mk = vsModel$mk
    yFun = mbasis %*% vsModel$coefs
    period = vsModel$period
    mMJD = min(vsModel$MJD)
    error = vsModel$error
    
    if(!folding){
        with(vsModel, 
            plot(MJD, mag, ylim=rev(range(mag)),pch=20))
        abline(v=1:nCyc*period+mMJD,col="red",lwd=1)
        for(i in 1:nCyc){
            sel=(cycPos==(i-1))
            #if(sum(sel)<1) next
            lines(grid*period+mMJD, ak[i]*yFun+mk[i])
            lines(grid*period+mMJD, 0*yFun+mk[i], lty=2,
                  col="red")
            grid = grid + 1
        }
    }else{
        MJDt = vsModel$MJD
        MJDt = MJDt - min(MJDt)
        
        ySample = vsModel$mag - mk[cycPos+1] + median(mk)
        plot(MJDt%%period,ySample,ylim=rev(range(ySample)),
             xlab="phase",ylab="magnitude",pch=20,type="n")
        errbar(MJDt%%period, ySample, ySample+error,
               ySample-error,add=TRUE,cap=0.01,pch=19,
               errbar.col="blue",lty=2)
        lines(grid*period, yFun + median(mk),lwd = 3, col= "red")
    }
}

