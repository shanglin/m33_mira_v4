#include "model.h"
#include <RcppArmadilloExtensions/sample.h>

//In this file, magnitude is modeled as
//a_k*f(phase)+m_k
//f is a function of phase, defined on (0,1)
//a_k and m_k varies from cycle to cycle
//currently impose a_k=1 for all cycles

varStar::varStar(NumericVector MJDI, NumericVector magI,
		    NumericVector errorI){
    MJD = vec(MJDI);
    mag = vec(magI);
    mag_sigma = vec(errorI);
    weight = vec(errorI);
    weight = 1/weight;
    nObs = MJD.n_elem;
}

// Set the period
// shift is UNIFORM(0, period)
void varStar::set_period(double prd, double shift){
    period = prd;
    vec tmpMJD;
    tmpMJD = MJD -min(MJD) + shift;
    cycPos = tmpMJD / period;
    phase = cycPos - floor(cycPos);

    //the number of cycles, which the observation is in,
    //from 0,1,2,....
    cycPos = floor(cycPos);
    
    nCyc = max(cycPos)+1; // total number of cycles

     DMbasis_eval();
}



void varStar::boot_shuffle(){
    // //cycles shuffle
     vec cycPosSh(nCyc);
     int i;
     // shuffle mapping
     for(i=0; i<nCyc; i++) cycPosSh[i] = i;
     cycPosSh = Rcpp::RcppArmadillo::sample(cycPosSh, nCyc, false);
     int oldCycPos, newCycPos;
     for(i=0; i<nObs; i++){
         oldCycPos = cycPos(i);
         newCycPos = cycPosSh(oldCycPos);
         cycPos(i) = newCycPos;
     }
 }

mat varStar::period_est(double sBegin, double sEnd, int sLength){
    RNGScope scope;
    //current frequency
    double currF = 1/sEnd; 
    int bootN = 20;
    mat residBoot(sLength, bootN+1, fill::zeros);
    double increF = (- 1/sEnd + 1/sBegin)/sLength;
    int i,j;
    double shift;
    //vec BIC(sLength);
    
    for(i=0; i<sLength; i++){
	//Rcout<<i<<std::endl;
        residBoot(i,0) = currF;
	set_period(1/currF,0);
	residBoot(i,1) = model_fit();
	//make a copy of the original
	resid_res = residuals;
	mag_res = mag;
	magFitted_res = magFitted;
        for(j=2; j<bootN+1; j++){
	    //resample the residuals
	    mag = magFitted_res +
		Rcpp::RcppArmadillo::sample(resid_res, nObs, true);
	    //make a shift
	    shift = R::runif(0,1/currF -1 );
            set_period(1/currF, shift);
	    // shuffling the order of the cycles
	    boot_shuffle();
            residBoot(i,j) = model_fit();
        }
        currF += increF;
	mag = mag_res;
    }
    return residBoot;
}




