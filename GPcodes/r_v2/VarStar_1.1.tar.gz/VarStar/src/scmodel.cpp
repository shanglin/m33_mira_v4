#include "scmodel.h"

sinusoidModel::sinusoidModel(NumericVector MJDI,
			     NumericVector magI,
			     NumericVector errorI):
  varStar(MJDI, magI, errorI){

}


// The design matrix function X
//X = (1 1 1 0 0 0 0; cos ; sin)
void sinusoidModel::DMbasis_eval()
{
    DMbasis = mat(nObs, nCyc+2, fill::zeros);
    int i,k;

    //Design Matrix
    for(i=1; i<nObs; i++){
	k = cycPos(i);
    	DMbasis(i ,k) = 1;
    }
    DMbasis.col(nCyc) = cos(2*PI*phase);
    DMbasis.col(nCyc+1) = sin(2*PI*phase);

    //Penalty term, L2
    Omega = mat(nCyc+2, nCyc+2, fill::zeros);
    
    for(i=0; i<nCyc-1; i++){
        Omega(i+1,i) = -1;
        Omega(i,i+1) = -1;
        Omega(i,i) = 2;
    }
    
    Omega(0,0) = 1;
    Omega(nCyc-1, nCyc-1) = 1;
}


//return CV error
double sinusoidModel::coef_eval(double lambda){
    //Least Square method, +lambda* first order diff regularize
    vec q(DMbasis.n_cols,fill::ones), magWgt, coefAll;
    mat DMwgt, DMwgtSq, H; //H hat matrix 
    int i,k;
    
    //DM: design matrix, y: magnitude, W: weight^2
    //Compute coefs = (DM^T*W*DM+lambda*Omega)^{-1}*DM^T*W*y
    DMwgt = kron(weight, q.t()) % DMbasis;
    magWgt = mag % weight;
    magWgt = DMwgt.t()*magWgt;
    DMwgtSq = DMwgt.t()*DMwgt + lambda * Omega;
    coefAll = solve(DMwgtSq, magWgt);
    
    //compute (CV) residuals
    double CVErr = 0, tmp;
    magFitted = DMbasis*coefAll;
    residuals = mag - magFitted;
    DMwgt = kron(weight%weight, q.t()) % DMbasis;
    //The hat matrix
    H = DMbasis * DMwgtSq.i() * DMwgt.t();
    for(i=0; i<nObs; i++){
        tmp = residuals(i)/(1-H(i,i))*weight(i); //weight(i);
        CVErr += tmp * tmp;
    }
    
    //extract coefs
    coefs = coefAll.subvec(nCyc, nCyc+1);
    mk = coefAll.subvec(0,nCyc-1);
    
    return CVErr;
}


double sinusoidModel::model_fit(){
    mk = vec(nCyc, fill::zeros);
    int i;
    //Cross validatoin and to find the
    //best tunnin parameter and coefficients
    double lambdas[] = {1200,900,600,300,100,80,30, 10, 2,0.4};
    double tmp, error_best;
    vec coefs_best, mk_best;
    error_best = 999999999999999;
    
    for(i=0; i<10; i++){
        tmp = coef_eval(lambdas[i]);
	if(tmp < error_best){
	    error_best = tmp;
	    coefs_best = coefs;
	    mk_best = mk;
	}
    }
    
    coefs = coefs_best;
    mk = mk_best;
    return error_best;
}



List sinusoidModel::get_model(){
    return List::create(Named("MJD")=MJD,
			Named("mag")=mag,
			Named("error")=1/weight,
			Named("period")=period,
			Named("nCyc")=nCyc,
			Named("cycPos")= cycPos,
			Named("mk")=mk,
			Named("coefs")=coefs);
}

RCPP_MODULE(varStar_m1){
    class_<varStar>("varStar")
	 .constructor<NumericVector, NumericVector, NumericVector>()
	.method("set_period", &sinusoidModel::set_period)
	.method("period_est", &sinusoidModel::period_est)
	;
    
    class_ <sinusoidModel>( "sinusoidModel")
	.derives<varStar>("varStar")
	.constructor<NumericVector, NumericVector, NumericVector>()
	.method("model_fit", &sinusoidModel::model_fit)
	.method("get_model", &sinusoidModel::get_model)
	//.method("get_fake", &sinusoidModel::get_fake)
	;
}
