#include "simple_gpmodel.h"

//p1 p2: position of first and second paraeter
//k==0: kernel value;
//k==1 partial deriv w.r.t. theta_1
//k==2: partial deriv w.r.t theta_2
//k(xx, yy)
//If K is symmetric, save half computation time
void simple_gpModel::kernel_SE(int p1, int p2,
			       int k, vec & xx, vec & yy,
			       bool symmetric){
    int i,j, jStart;
    int nK1, nK2;
    bool zero_out;
    nK1 = xx.n_elem;
    nK2 = yy.n_elem;
    double tmpE,tmpE_deriv, tmpK, tmpDiff;
    kernel_K = mat(nK1, nK2, fill::zeros);
    kernel_partialK = kernel_K;


    jStart = 0;
    for(i=0; i< nK1; i++){
	if(symmetric) jStart = i;
	for(j=jStart; j<nK2; j++){
	    tmpDiff = xx(i) - yy(j);
	    zero_out = false;
	    //if(abs(tmpDiff)>1500) zero_out = true;
	    //long term trend
	    tmpE = tmpDiff * tmpDiff /(2*theta(p2)*theta(p2));
	    if(k==0){
		tmpK = theta(p1)*theta(p1)*exp(-tmpE);
		kernel_K(i,j) = tmpK;
		if(zero_out) kernel_K(i,j) = 0;
		if(symmetric) kernel_K(j,i) = kernel_K(i,j);
	    }else if(k==1){
		tmpK = 2*theta(p1)*exp(-tmpE);
		kernel_partialK(i,j) = tmpK;
		if(zero_out) kernel_partialK(i,j) = 0;
		if(symmetric) kernel_partialK(j,i) = kernel_partialK(i,j);
	    }else if(k==2){
		tmpK = theta(p1)*theta(p1)*exp(-tmpE);
		tmpE_deriv = 2*tmpE/theta(p2);
		tmpK *= tmpE_deriv;
		kernel_partialK(i,j) = tmpK;
		if(zero_out) kernel_partialK(i,j) = 0;
		if(symmetric) kernel_partialK(j,i) = kernel_partialK(i,j);
	    }
	}
    }
}



//p1 p2: position of first and second paraeter
//k==0: kernel value; k==1 partial deriv w.r.t. theta_1
//k==2: partial deriv w.r.t theta_2
//k(xx, yy)
//Matern Class nu = 3/2
//Unlike kernel_SE, symmetric not implemented yet
void simple_gpModel::kernel_matern(int p1, int p2,
				   int k, vec & xx, vec & yy,
				   bool symmetric){
    int i,j;
    int nK1, nK2;
    nK1 = xx.n_elem;
    nK2 = yy.n_elem;
    double tmpE, tmpK, tmpDiff,tmpED, tmpKD;
    kernel_K = mat(nK1, nK2, fill::zeros);
    kernel_partialK = kernel_K;
    for(i=0; i<nK1; i++){
	for(j=0; j<nK2; j++){
	    tmpDiff = xx(i) - yy(j);
	    tmpDiff = abs(tmpDiff);
	    tmpE = tmpDiff * sqrt(3)/theta(p2);  //sqrt(5)
	    tmpK = theta(p1)*theta(p1)*(1+tmpE)*exp(-tmpE);
	    if(k==0){
		    kernel_K(i,j) = tmpK;
	    }else if(k==1){
	       tmpKD = 2*theta(p1)*(1+tmpE)*exp(-tmpE);
		    kernel_partialK(i,j) = tmpKD;
	    }else if(k==2){
	    	tmpED = - tmpE/theta(p2);
	    	tmpKD = theta(p1)*theta(p1)* tmpED*exp(-tmpE) - 
		    tmpK*tmpED;
		kernel_partialK(i,j) = tmpKD;
	    }
	}
    }
}



//compute the variance/covariance matrix: k(xx, yy)
//k==-1: training data, used in prediction
//k==0: training data, theta estimation
//k==1: cov(new, train) --> gp_K21
//k==2: var(new) --> gp_K22
void simple_gpModel::compute_CovM(vec & xx, vec & yy, int k){
    // compute kernel
    bool symmetric = false;
    if(k<=0) symmetric = true;
    double condN = 0;


    kernel_SE(0, 1, 0, xx, yy, symmetric);
    //kernel_matern(0,1,0,xx,yy);
    if(k<=0){
        gp_Kc = kernel_K;
        for(int i=0; i<nObs; i++){
            gp_Kc(i, i)  += mag_sigma(i)*mag_sigma(i)
            + 0.0009;  //relaxed
        }
        gp_Ky = gp_Kc + HtBH;
        
        //condN = cond(gp_Ky);
        
        //if(condN<5e6 || k==-1){
            flag_inv = true;
            //log determinant
            gp_Ky_chol = chol(gp_Ky);
            vec gp_Ky_diag = gp_Ky_chol.diag();
            gp_Ky_logdet = sum(log(gp_Ky_diag));
            gp_Ky_logdet = 2 * gp_Ky_logdet;
            
            //inverse
            alpha = solve(trimatl(gp_Ky_chol.t()), gp_y);
            alpha = solve(trimatu(gp_Ky_chol), alpha);
            if(k==-1) gp_Kc_inv = gp_Kc.i();
        //}else
        //    flag_inv = false;
    }else if (k==1){
	    gp_K21 = kernel_K;
    }else if(k==2){
	    gp_K22 = kernel_K;
    }
}

//copmute minus log likelihood of the data
// this the joint density of y and theta
double simple_gpModel::gp_mLoglik(NumericVector theta_){
    double mLoglik;
    gp_setTheta(theta_);
    compute_CovM(MJD, MJD, 0);

    if(flag_inv && abs(theta(0))<6  && theta(1)>2 && theta(1)<500){
        //log_det(mLoglik, signL, gp_Ky);
        mLoglik =0.5*gp_Ky_logdet +
        0.5*nObs*log(2*PI)+
        0.5* as_scalar(gp_y.t()*alpha);
        
        //Rcout<<as_scalar(gp_y.t()*alpha)<<std::endl;
        //Rcout<<as_scalar(gp_y.t()*gp_Ky_inv*gp_y)<<std::endl;
        
        double tmp1, tmp2;
        tmp1 = theta(0)-mu1;
        tmp1 = 0.5*tmp1*tmp1/sigmaSq1 + 0.5*log(2*PI*sigmaSq1);
        tmp2 = log10(theta(1))+1.235-1.178*log10(period);
        tmp2 = 0.5*tmp2*tmp2/sigmaSq2+ 0.5*log(2*PI*sigmaSq2);
        mLoglik += tmp1+tmp2;
        
    }else{
        mLoglik = 1.0e50;
    }
    
    return mLoglik;
}

//compute the partial derivative of the minus log likelihood
vec simple_gpModel::gp_DmLoglik(NumericVector theta_){
    vec partialDeri(2,fill::zeros);
    gp_setTheta(theta_);
    //compute_CovM(MJD, MJD, 0); // save a little time by Optim

    mat tempI = eye(nObs,nObs);
    //Rcout<<gp_Ky_inv(20,30)<<std::endl;
    gp_Ky_inv = solve(trimatl(gp_Ky_chol.t()), tempI);
    gp_Ky_inv = solve(trimatu(gp_Ky_chol), gp_Ky_inv);
    //Rcout<<gp_Ky_inv(20,30)<<std::endl;
    
    
    mat prodTmp;
    prodTmp = alpha*alpha.t() - gp_Ky_inv;

    //kernel
    int j;
    for(j=0; j<2;j++){
       kernel_SE(0,1, j+1, MJD, MJD, true);
       partialDeri(j) = -0.5*trace(prodTmp*kernel_partialK);
    }
    
    double tmp1, tmp2;
    tmp1 = theta(0)-mu1;
    tmp1 = tmp1/sigmaSq1;
    tmp2 = log10(abs(theta(1)))+1.235-1.178*log10(period);
    tmp2 = tmp2/sigmaSq2 / (abs(theta(1)));
    partialDeri(0) += tmp1;
    partialDeri(1) += tmp2;
    return partialDeri;
}


//copmute minus log likelihood of the data
//not updated after changes
// double simple_gpModel::gp_mLoglikCV(NumericVector theta_){
//     double mLoglikCV = 0;
//     vec alpha;
//     gp_setTheta(theta_);
           
//     compute_CovM(MJD, MJD, 0);
//     if(flag_inv){
// 	alpha = Omega * gp_y;

// 	int i;
// 	double mu_i,sigmaSq_i, tmp;
// 	for(i=0; i<nObs; i++){
// 	    sigmaSq_i = 1/Omega(i,i);
// 	    mu_i = gp_y(i) - alpha(i)*sigmaSq_i;
// 	    tmp = gp_y(i) - mu_i;
// 	    mLoglikCV += 0.5*log(sigmaSq_i) + 0.5*tmp*tmp/sigmaSq_i;
// 	}

// 	double tmp1, tmp2;
// 	tmp1 = theta(0)-mu1;
// 	tmp1 = 0.5*tmp1*tmp1/sigmaSq1;
// 	tmp2 = log10(theta(1))+1.235-1.178*log10(period);
// 	tmp2 = 0.5*tmp2*tmp2/sigmaSq2;
// 	mLoglikCV += tmp1+tmp2;
//     }else
// 	mLoglikCV = 1.0e50;
      
//     return mLoglikCV;
// }

//compute the partial derivative of the minus log likelihood
//not updated after changes
// vec simple_gpModel::gp_DmLoglikCV(NumericVector theta_){
//     vec partialDeri(2,fill::zeros);
//     gp_setTheta(theta_);
//     //compute_CovM(MJD, MJD, 0);
    
//     vec alpha, ZjAlpha;
//     mat Zj, ZjOmega;
//     int i, j;
//     double tmp;
    
//     alpha = Omega * gp_y;
//     //kernel
//     for(j=0;j<2;j++){
// 	kernel_SE(0,1,j+1, MJD, MJD, true);
// 	//kernel_matern(0,1,1,MJD,MJD);
// 	Zj = Omega * kernel_partialK;
// 	ZjOmega = Zj*Omega;
// 	ZjAlpha = Zj*alpha;
// 	partialDeri(j) = 0;
// 	for(i=0; i<nObs; i++){
// 	    tmp = alpha(i)*ZjAlpha(i);
// 	    tmp -= 0.5*(1+alpha(i)*alpha(i)/Omega(i,i))*ZjOmega(i,i);
// 	    tmp /= Omega(i,i);
// 	    partialDeri(j) -= tmp;
// 	}//nObs
//     }//j

//     double tmp1, tmp2;
//     tmp1 = abs(theta(0))-mu1;
//     tmp1 = tmp1/sigmaSq1;
//     tmp2 = log10(abs(theta(1)))+1.235-1.178*log10(period);
//     tmp2 = tmp2/sigmaSq2/ (abs(theta(1))+0.00001) / 2.3025;;
//     partialDeri(0) += tmp1;
//     partialDeri(1) += tmp2;
//     return partialDeri;
// }


//set theta 
void simple_gpModel::gp_setTheta(NumericVector theta_){
    theta = vec(theta_);
    theta = abs(theta) + 0.00001;
}


//The design matrix: n-by-3
//(1,cos(xx), sin(xx))
mat simple_gpModel::gp_get_Ht(vec xx){
    int nK = xx.n_elem;
    mat Ht_tmp = mat(nK, 3, fill::ones);
    xx = xx*2*PI/period;
    Ht_tmp(span::all, 1) = cos(xx);
    Ht_tmp(span::all, 2) = sin(xx);
    return Ht_tmp;
}

void simple_gpModel::set_period(double prd, double shift){
    period = prd;
    //new design matrix after changing period
    Ht = gp_get_Ht(MJD);
    HtBH =  Ht*Sigma_gamma*Ht.t();
}

//predict at Xnew (t*)
//Posterior distribution of gamma and Ynew
List simple_gpModel::gp_predict(NumericVector Xnew_){
    Xnew = vec(Xnew_);
    
    vec resid_hat;
    //mat resid_Omega,resid_Sigma;
    //double mLoglik_resid = 0, signL;

    //-1 cov of training data, gp_Kc_inv is also computed
    compute_CovM(MJD, MJD, -1);
    //resid_Omega = gp_Ky_inv;
    //resid_Sigma = gp_Ky;
    
    compute_CovM(Xnew, MJD, 1);
    compute_CovM(Xnew, Xnew, 2);

    //get the design matrix
    mat Ht_star = gp_get_Ht(Xnew);

    //posterior mean of gamma and new Y
    vec gamma_bar, predY;
    //posterior covariance matrix of gamma and new Y
    mat tmp1, tmp2, tmp_r, pcov_predY,pcov_gamma;
    
    tmp1 = Sigma_gamma.i();
    tmp1 += Ht.t()*gp_Kc_inv*Ht;
    tmp2 = Sigma_gamma.i()*gamma0+ Ht.t()*gp_Kc_inv*(gp_y+gp_m);
    pcov_gamma = inv(tmp1);
    gamma_bar = pcov_gamma*tmp2;
    
    resid_hat = gp_y+ gp_m- Ht*gamma_bar;
    predY = Ht_star*gamma_bar + 
            gp_K21 * gp_Kc_inv * resid_hat;
    tmp_r = Ht_star.t() - Ht.t() * gp_Kc_inv *gp_K21.t();
    pcov_predY = gp_K22 - gp_K21 * gp_Kc_inv * gp_K21.t();
    pcov_predY += tmp_r.t() * pcov_gamma * tmp_r;
    //    log_det(mLoglik_resid, signL, resid_Sigma);
    //mLoglik_resid =0.5*mLoglik_resid +
    //	0.5* as_scalar(resid_hat.t()*resid_Omega*resid_hat);

    return List::create(Named("predy")=predY,
			Named("predy_cov") = pcov_predY,
			Named("gamma_bar")=gamma_bar,
			Named("gamma_cov") = pcov_gamma,
			Named("Ht_star") = Ht_star
			);
}

simple_gpModel::simple_gpModel(NumericVector MJD_,
		 NumericVector mag_, NumericVector error_,
		 NumericVector hyper):
    varStar(MJD_, mag_, error_)
{
    gp_m = hyper[0];
    sigmamSq = hyper[1];
    sigmabSq= hyper[2];
    mu1 = hyper[3];
    mu2 = hyper[4];
    sigmaSq1 = hyper[5];
    sigmaSq2 = hyper[6];

    //priors for gamma
    gamma0 = vec(3,fill::zeros);
    gamma0(0) = gp_m;
    Sigma_gamma = mat(3, 3, fill::zeros);
    Sigma_gamma(0,0) = sigmamSq;
    Sigma_gamma(1,1) = sigmabSq;
    Sigma_gamma(2,2) = sigmabSq;
    // remove the overall prior mean
    gp_y = mag - gp_m;
}



RCPP_MODULE(varStar_m3){
    class_<varStar>("varStar")
	 .constructor<NumericVector, NumericVector,
		      NumericVector>()
	;
    
    class_ <simple_gpModel>( "simple_gpModel")
	.derives<varStar>("varStar")
	.constructor<NumericVector, NumericVector,
		     NumericVector, NumericVector>()
	.method("gp_setTheta", &simple_gpModel::gp_setTheta)
	.method("gp_mLoglik", &simple_gpModel::gp_mLoglik)
	.method("gp_DmLoglik", &simple_gpModel::gp_DmLoglik)
	//.method("gp_mLoglikCV", &simple_gpModel::gp_mLoglikCV)
	//.method("gp_DmLoglikCV", &simple_gpModel::gp_DmLoglikCV)
	.method("gp_predict", &simple_gpModel::gp_predict)
	.method("set_period", &simple_gpModel::set_period)
	;
}
