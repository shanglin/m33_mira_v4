#ifndef MODELSINCLASS
#define MODELSINCLASS

#include "model.h"
#include "spline.h"

class sinusoidModel: public varStar{
 protected:
    //model file product
    // m_k+ a_k* b(t)^T * coefs
    vec mk;  
    vec coefs;
    mat Omega;
    
    void DMbasis_eval();
    double coef_eval(double );
     
    
 public:
    sinusoidModel(NumericVector, NumericVector, NumericVector);
    double model_fit();
    List get_model();
    //mat get_fake(NumericVector, double);
};

#endif
